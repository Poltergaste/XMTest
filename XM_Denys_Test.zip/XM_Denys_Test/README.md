Hello! In this small readme I'd like to make a small tutorial about my project.

To start the Calendar test, you can find in by path:
test/java/CalendarTest.java

WebElements are described by pages and stored by path:
src/main/java/pageElements

The ChromeSettings are stored in 
src/main/java/utils
